# Temporarily storing OTPs (for demonstration only, use DB in production)
otp_db = {}
